package com.bignerdranch.android.pr1923


public class User(var name:String,var age:Int=0) {
    @Override
    fun info(){
        println("Имя: $name\nВозраст: $age")
    }
}