package com.bignerdranch.android.pr1923

import android.annotation.SuppressLint
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {
    lateinit var edit1:EditText
    lateinit var edit2:EditText
    lateinit var adapter:Adapter
    var name:String=""
    var age:Int = 0
    lateinit var user:List<User>
    lateinit var listwiev:ListView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        edit1=findViewById(R.id.editText)
        edit2=findViewById(R.id.editText2)
        listwiev=findViewById(R.id.ListView)
        user= listOf()
        adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,user)
        listwiev.adapter = adapter as ArrayAdapter<User>
        var User:User= User(name,age)



    }

    fun f1(){
        edit1=findViewById(R.id.editText)
        edit2=findViewById(R.id.editText2)
        if(edit1.text.toString()!="" && edit2.text.toString()!=""){

        }
        else{
            Toast.makeText(this,"неправильно", Toast.LENGTH_SHORT).show()
        }
    }
}